Log a statment using console.log()
console.log('Hello from Me.js')

Varibles

let age = 25
console.log(age)

const salary = 0
salary = 80000
console.log(salary)

let sum = 0
sum = 5
console.log(sum)

const name = 'Vishwas'
const language = 'JavaScript'
const channel = 'Codevolution'

const totla = 0
const PI = 3.14

const isPrimaryNumber = true
const IsNewUser = false

let result
console.log(result)

const res = null

const data = null

const person = {
    FirstName: 'Bruce',
    lastname: 'Wayne',
    age: 30.
}

console.log(person.FirstName)

const oddNumbers = [1, 3, 5, 7, 9]
console.log(oddNumbers[1])

let a = 10
a = 'Vishwas'
a = 'true'
console.log(a)

let x = 10
let y = 5

console.log(x % y)
console.log(++x)
console.log(--x)

console.log(x >= y)

const isValidNumner = x > 8 || 8 > y
console.log(isValidNumner)

const isValid = false
console.log(!isValid)

console.log('Bruce ' + 'Wayne')

const isEven = 10 % 2 === 0 ? 'Nuber is even' : 'Number is odd'
console.log(isEven)

console.log(true + ' 3')
console.log('4' - '2')
console.log('Bruce' - 'Wayne')
console.log('5' - null)
console.log(5 + undefined)

console.log(parseFloat('3.14'))
console.log(String(undefined))
console.log((500).toString())
console.log(Boolean(10)) //null undefind 0 '' NaN

const var1 = null
const var2 = undefined

console.log(var1 == var2)
console.log(var1 === var2)

const num = 0

if(num > 0) {
    console.log('Number is Positive')
}
else if (num < 0) {
    console.log('Number is negative')
}
else {
    console.log('Number is zero')
}

const color = 10

switch(color) {
    case 'red':
        console.log('Color is red')
        break
    case 'blue':
        console.log('Color is blue')
        break
    case 'green':
        console.log('Color is green')
        break
        default:
            console.log('Not a valid color')
}

for(let i = 1; i <= 5; i++) {
    console.log('Iteration number ' + i)
}

let i = 1
while (1 <= 5) {
    console.log('Iteration nuber ' + i)
    i++
}

let i = 1
do {
    console.log('Iteration number ' + i)
    i++
} while (i <= 5)

const numArray = [1, 2, 3, 4, 5]

for (const num of numArray) {
    console.log('Iteration number ' + num)
}

function greet(username) {
    console.log('Good morning ' + username)
}

greet('Bruce')
greet('Clark')
greet('Diana')


function add(a, b) {
    return a + b
}

const arrowSum = (a, b) => a + b
const addFive = (num) => num + 5


const sum = add(25, 25)
console.log(sum)

const myNum = 100
const myName = 'SuperMan'

if(true) {
    const myName = 'Vishwas'
    console.log(myName)
    console.log(myNum)
}

function testFn() {
    const myName = 'Batman'
    console.log(myName)
    console.log(myNum)
}

testFn()